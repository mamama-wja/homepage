$(document).ready(function(){
	var domain = "xxxx.com";
	$("#k30s").click(function(){
        window.open("https://qm.qq.com/cgi-bin/qm/qr?k=HiPjhr3IhfnJTNJwEyarXG3m7WN4zbDm&jump_from=webapi&authKey=SbLmKQGiNN45utg98WuteMcuzVSwIG+k2+cpSPxuItSIzoV13bM6yvoqWtEttQJ+");
    });
    $("#12s").click(function(){
        window.open("https://qm.qq.com/cgi-bin/qm/qr?k=qCWMCEiBelLS8Am4GrpynXbmPDRHX6lC&jump_from=webapi&authKey=11Am1njwF6i+95mClkxMpXzQxTc2bpvCA9FwRWUQy5weviHQeDF5/kkoTPVqV9yE");
    });
})